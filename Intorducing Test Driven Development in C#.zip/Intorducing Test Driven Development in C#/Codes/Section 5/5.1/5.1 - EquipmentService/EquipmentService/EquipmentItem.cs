﻿namespace EquipmentService
{
    public class EquipmentItem
    {
        public string Name { get; set; }
    }
}
