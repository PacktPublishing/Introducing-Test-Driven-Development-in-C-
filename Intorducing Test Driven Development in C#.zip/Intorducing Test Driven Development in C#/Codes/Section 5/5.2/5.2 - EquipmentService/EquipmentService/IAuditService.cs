﻿namespace EquipmentService
{
    public interface IAuditService
    {
        void WriteEmploeeInformation(Employee employee);
    }
}
