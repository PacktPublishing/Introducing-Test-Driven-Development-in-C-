﻿namespace DependencyInversionPrincipleGood
{
    public interface ICalendarItem
    {
        void Start();
    }
}
