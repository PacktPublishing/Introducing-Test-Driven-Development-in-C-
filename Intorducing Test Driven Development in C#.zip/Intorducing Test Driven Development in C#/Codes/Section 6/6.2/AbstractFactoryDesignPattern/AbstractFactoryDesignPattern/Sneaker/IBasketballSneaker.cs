﻿namespace AbstractFactoryDesignPattern
{
    public interface IBasketballSneaker
    {
        int GetPrice();
    }
}
