﻿namespace AbstractFactoryDesignPattern
{
    public class NikeMercurialSuperfly : ISoccerSneaker
    {
        public int GetPrice()
        {
            return 200;
        }
    }
}
