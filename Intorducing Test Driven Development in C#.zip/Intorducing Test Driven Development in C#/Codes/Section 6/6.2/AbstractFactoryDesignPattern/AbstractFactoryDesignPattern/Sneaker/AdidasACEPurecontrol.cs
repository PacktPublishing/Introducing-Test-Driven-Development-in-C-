﻿namespace AbstractFactoryDesignPattern
{
    public class AdidasACEPurecontrol : ISoccerSneaker
    {
        public int GetPrice()
        {
            return 50;
        }
    }
}
