﻿namespace AbstractFactoryDesignPattern
{
    public interface ISoccerSneaker
    {
        int GetPrice();
    }
}
