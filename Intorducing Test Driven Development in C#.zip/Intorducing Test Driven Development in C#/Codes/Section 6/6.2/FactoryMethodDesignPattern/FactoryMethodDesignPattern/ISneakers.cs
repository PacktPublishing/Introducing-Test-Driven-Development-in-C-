﻿namespace FactoryMethodDesignPattern
{
    public interface ISneakers
    {
        int SneakingLevel { get; set; }
    }
}
