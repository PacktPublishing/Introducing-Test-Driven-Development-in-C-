﻿namespace FactoryMethodDesignPattern
{
    public interface ISneakersProvider
    {
        ISneakers Provide();
    }
}
