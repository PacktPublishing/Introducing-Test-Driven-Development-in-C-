﻿namespace BlogTests
{
    public class TestClass
    {
        public int Id { get; set; }
    }
}
