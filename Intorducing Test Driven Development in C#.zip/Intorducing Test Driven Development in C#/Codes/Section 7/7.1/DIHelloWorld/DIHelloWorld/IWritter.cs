﻿namespace DIHelloWorld
{
    public interface IWritter
    {
        void WriteHelloWorld();
    }
}
