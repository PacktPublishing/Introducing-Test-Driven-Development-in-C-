﻿namespace Autofac
{
    public interface IService1
    {
        void Service1Method();
    }
}
