﻿namespace Autofac
{
    public class Service2 : IService2
    {
        public void Service2Method()
        {
            // Service Method Implementation
        }
    }
}
