﻿namespace StructureMap
{
    public interface IService2
    {
        void Service2Method();
    }
}
