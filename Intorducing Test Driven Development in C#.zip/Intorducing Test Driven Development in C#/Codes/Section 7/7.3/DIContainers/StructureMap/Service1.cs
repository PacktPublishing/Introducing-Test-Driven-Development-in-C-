﻿namespace StructureMap
{
    public class Service1 : IService1
    {
        public void Service1Method()
        {
            // Service Method Implementation
        }
    }
}
