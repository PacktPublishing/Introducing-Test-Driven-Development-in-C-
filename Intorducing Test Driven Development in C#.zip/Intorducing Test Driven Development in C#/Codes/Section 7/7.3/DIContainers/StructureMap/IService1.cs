﻿namespace StructureMap
{
    public interface IService1
    {
        void Service1Method();
    }
}
