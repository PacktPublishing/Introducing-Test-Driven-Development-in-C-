﻿namespace CastleWindsor
{
    public interface IService2
    {
        void Service2Method();
    }
}
