﻿namespace ClientServicePropertyExample
{
    public interface IService
    {
        void ServiceMethod();
    }
}
