﻿using System;

namespace ClientServiceExample
{
    public class Service : IService
    {
        public void ServiceMethod()
        {
            Console.WriteLine("Service Method initiated");

            // Service Method implementation.
        }
    }
}
