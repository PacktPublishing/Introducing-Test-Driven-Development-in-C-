﻿namespace ClientServiceExample
{
    public interface IService
    {
        void ServiceMethod();
    }
}
