﻿namespace SRP
{
    public enum EntityType
    {
        Type0 = 0,
        Type1 = 1,
        Type2 = 2
    }
}
