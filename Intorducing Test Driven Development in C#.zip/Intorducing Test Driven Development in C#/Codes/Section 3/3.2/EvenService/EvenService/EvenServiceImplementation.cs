﻿using System;

namespace EvenService
{
    public class EvenServiceImplementation
    {
        public bool IsEven(int number)
        {
            return number%2 == 0;
        }
    }
}
