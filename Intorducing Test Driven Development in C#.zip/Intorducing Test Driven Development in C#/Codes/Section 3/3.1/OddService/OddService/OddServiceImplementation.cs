﻿namespace OddService
{
    public class OddServiceImplementation
    {
        public bool IsOdd(int number)
        {
            return number%2 != 0;
        }
    }
}
